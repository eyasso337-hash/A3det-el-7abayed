const express = require('express');
const session = require('express-session');
const path = require('path');
const crypto = require('crypto');
const app = express();
const PORT = process.env.PORT || 3000;
const { DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET, DISCORD_REDIRECT_URI, DISCORD_GUILD_ID, DISCORD_BOT_TOKEN, SESSION_SECRET } = process.env;
const required = ['DISCORD_CLIENT_ID','DISCORD_CLIENT_SECRET','DISCORD_REDIRECT_URI','DISCORD_GUILD_ID','DISCORD_BOT_TOKEN','SESSION_SECRET'];
app.set('trust proxy', 1);
app.use(session({
  name: 'a3h.sid', secret: SESSION_SECRET || crypto.randomBytes(32).toString('hex'),
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 7*24*60*60*1000 }
}));
app.use(express.static(path.join(__dirname, 'public')));
function configCheck(req,res,next) {
  const missing = required.filter(k => !process.env[k]);
  if (missing.length) return res.status(503).send('الموقع لسه محتاج إعدادات Discord. الإعدادات الناقصة: ' + missing.join(', ') + '. راجع README.txt.');
  next();
}
app.get('/auth/discord', configCheck, (req,res) => {
  const state = crypto.randomBytes(24).toString('hex');
  req.session.oauthState = state;
  const url = new URL('https://discord.com/oauth2/authorize');
  url.searchParams.set('client_id', DISCORD_CLIENT_ID);
  url.searchParams.set('redirect_uri', DISCORD_REDIRECT_URI);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('scope', 'identify');
  url.searchParams.set('state', state);
  res.redirect(url.toString());
});
app.get('/auth/callback', configCheck, async (req,res) => {
  try {
    if (!req.query.code || !req.query.state || req.query.state !== req.session.oauthState) return res.status(400).send('طلب تسجيل الدخول غير صالح. ارجع للموقع وحاول مرة أخرى.');
    delete req.session.oauthState;
    const body = new URLSearchParams({ client_id: DISCORD_CLIENT_ID, client_secret: DISCORD_CLIENT_SECRET, grant_type: 'authorization_code', code: req.query.code, redirect_uri: DISCORD_REDIRECT_URI });
    const tokenRes = await fetch('https://discord.com/api/oauth2/token', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body });
    const token = await tokenRes.json();
    if (!tokenRes.ok) return res.status(400).send('فشل تسجيل الدخول. راجع Client ID وClient Secret وRedirect URI.');
    const userRes = await fetch('https://discord.com/api/users/@me', { headers:{Authorization:`Bearer ${token.access_token}`} });
    const user = await userRes.json();
    if (!userRes.ok) return res.status(400).send('تعذر جلب بيانات حساب Discord.');
    // Bot token is used server-side only to check membership and resolve role names.
    const memberRes = await fetch(`https://discord.com/api/guilds/${DISCORD_GUILD_ID}/members/${user.id}`, { headers:{Authorization:`Bot ${DISCORD_BOT_TOKEN}`} });
    let member = null;
    if (memberRes.ok) member = await memberRes.json();
    let roles = [];
    if (member && Array.isArray(member.roles)) {
      const rolesRes = await fetch(`https://discord.com/api/guilds/${DISCORD_GUILD_ID}/roles`, { headers:{Authorization:`Bot ${DISCORD_BOT_TOKEN}`} });
      if (rolesRes.ok) {
        const guildRoles = await rolesRes.json();
        roles = member.roles.map(id => guildRoles.find(role => role.id === id)).filter(Boolean).map(role => ({id:role.id,name:role.name,color:role.color}));
      }
    }
    req.session.memberProfile = { user:{id:user.id,username:user.username,global_name:user.global_name||null,avatar:user.avatar||null}, inGuild:!!member, roles };
    res.redirect('/#memberDashboard');
  } catch (err) { console.error('OAuth callback failed:', err); res.status(500).send('حصل خطأ أثناء تسجيل الدخول. راجع إعدادات الموقع وحاول مرة أخرى.'); }
});
app.get('/api/me', (req,res) => { if (!req.session.memberProfile) return res.status(401).json({loggedIn:false}); res.json({loggedIn:true,...req.session.memberProfile}); });
app.get('/auth/logout', (req,res) => req.session.destroy(() => res.redirect('/')));
app.listen(PORT, () => console.log(`A3det el 7abayed website listening on port ${PORT}`));
